package com.tmavn.sample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class AppConfigTest {

    @InjectMocks
    public AppConfig appConfig;

    @Before
    public void setUp() throws Exception {
        appConfig = new AppConfig();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test() {
        Properties prop = new Properties();
        prop.setProperty("test", "org.postgresql");

        appConfig.setHibProperties(prop);
        appConfig.setOperationId("id1");

        assertTrue(appConfig.getHibProperties().containsKey("test"));
        assertEquals(appConfig.getOperationId(), "id1");
    }
}
