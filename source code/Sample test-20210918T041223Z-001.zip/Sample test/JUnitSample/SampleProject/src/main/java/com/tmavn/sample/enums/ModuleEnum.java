/*
 * Demo project
 */
package com.tmavn.sample.enums;

/**
 * The Enum ModuleEnum.
 */
public enum ModuleEnum {

    /** The sample. */
    SAMPLE_MODULE, OPS_MODULE
}
